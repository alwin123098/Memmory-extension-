(function() {
    'use strict';

    // Configuration for different AI platforms
    const PLATFORM_CONFIG = {
        'chatgpt.com': {
            inputSelector: '#prompt-textarea',
            submitSelector: '[data-testid="send-button"]'
        },
        'claude.ai': {
            inputSelector: 'div[contenteditable="true"]',
            submitSelector: 'button[aria-label="Send Message"]'
        },
        'gemini.google.com': {
            inputSelector: 'div[role="textbox"]',
            submitSelector: 'button[aria-label="Send message"]'
        }
    };

    function getPlatformConfig() {
        const host = window.location.hostname;
        for (const [key, config] of Object.entries(PLATFORM_CONFIG)) {
            if (host.includes(key)) return config;
        }
        return null;
    }

    // Initialize UI Elements
    function init() {
        if (document.getElementById('pg-root')) return;

        const root = document.createElement('div');
        root.id = 'pg-root';
        document.body.appendChild(root);

        // Floating Button
        const button = document.createElement('div');
        button.id = 'pg-float-btn';
        button.innerHTML = '📌 Rules';
        root.appendChild(button);

        // Sidebar Overlay
        const sidebar = document.createElement('div');
        sidebar.id = 'pg-sidebar';
        sidebar.innerHTML = `
            <div class="pg-sidebar-header">
                <h2>PromptGuard</h2>
                <span id="pg-close-btn">&times;</span>
            </div>
            <div class="pg-sidebar-body">
                <label for="pg-rules-input">Permanent AI Rules:</label>
                <textarea id="pg-rules-input" placeholder="e.g., Always write clean Python code, no explanations."></textarea>
                <div class="pg-actions">
                    <button id="pg-save-btn">Save Rules</button>
                    <button id="pg-inject-btn">Inject & Send</button>
                </div>
                <div id="pg-status"></div>
            </div>
        `;
        root.appendChild(sidebar);

        // Event Listeners
        button.addEventListener('click', () => sidebar.classList.toggle('active'));
        document.getElementById('pg-close-btn').addEventListener('click', () => sidebar.classList.remove('active'));

        const rulesInput = document.getElementById('pg-rules-input');
        const statusEl = document.getElementById('pg-status');

        // Load saved rules
        chrome.storage.local.get(['pg_rules'], (result) => {
            if (result.pg_rules) {
                rulesInput.value = result.pg_rules;
            }
        });

        // Save rules logic
        document.getElementById('pg-save-btn').addEventListener('click', () => {
            const rules = rulesInput.value;
            chrome.storage.local.set({ pg_rules: rules }, () => {
                showStatus('Rules saved successfully!', 'success');
            });
        });

        // Inject rules logic
        document.getElementById('pg-inject-btn').addEventListener('click', () => {
            const rules = rulesInput.value;
            if (!rules.trim()) {
                showStatus('Please enter rules first.', 'error');
                return;
            }
            injectAndSend(rules);
        });

        function showStatus(msg, type) {
            statusEl.textContent = msg;
            statusEl.className = type;
            setTimeout(() => { statusEl.textContent = ''; }, 3000);
        }
    }

    function injectAndSend(text) {
        const config = getPlatformConfig();
        if (!config) {
            alert('PromptGuard: Platform not supported or recognized.');
            return;
        }

        const inputArea = document.querySelector(config.inputSelector);
        if (!inputArea) {
            alert('PromptGuard: Could not find input area. Please try again or refresh.');
            return;
        }

        // Handle contenteditable vs textarea
        if (inputArea.tagName === 'TEXTAREA' || inputArea.tagName === 'INPUT') {
            inputArea.value = text;
        } else {
            inputArea.innerText = text;
        }
        
        // Dispatch events to notify the site of changes
        inputArea.dispatchEvent(new Event('input', { bubbles: true }));
        inputArea.dispatchEvent(new Event('change', { bubbles: true }));

        // Small delay to ensure the site processes the input before clicking submit
        setTimeout(() => {
            const submitBtn = document.querySelector(config.submitSelector);
            if (submitBtn) {
                submitBtn.click();
                document.getElementById('pg-sidebar').classList.remove('active');
            } else {
                console.warn('PromptGuard: Submit button not found.');
            }
        }, 300);
    }

    // Run initialization
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        init();
    } else {
        document.addEventListener('DOMContentLoaded', init);
    }

    // Handle dynamic page changes (for SPA navigation)
    const observer = new MutationObserver((mutations) => {
        if (!document.getElementById('pg-root')) {
            init();
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });

})();
