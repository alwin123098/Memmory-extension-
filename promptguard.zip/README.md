# PromptGuard Chrome Extension

PromptGuard is a premium, lightweight Chrome extension designed for ChatGPT, Claude, and Gemini. It allows you to save permanent AI formatting or coding rules and inject them into your chat sessions with a single click.

## Features
- **Floating "📌 Rules" Button**: Elegant button injected into supported AI sites.
- **Sliding Sidebar**: Modern, premium UI for managing your rules.
- **Local Storage**: Rules persist across page refreshes.
- **One-Click Injection**: Automatically pastes rules and submits the chat.
- **Platform Support**: Works on `chatgpt.com`, `claude.ai`, and `gemini.google.com`.

## Installation Instructions

1. **Download the Code**: Save the provided `manifest.json`, `content.js`, and `content.css` into a folder named `promptguard` on your computer.
2. **Open Chrome Extensions**: In your Google Chrome browser, navigate to `chrome://extensions/`.
3. **Enable Developer Mode**: Toggle the "Developer mode" switch in the top right corner.
4. **Load Unpacked**: Click the "Load unpacked" button in the top left.
5. **Select Folder**: Select the `promptguard` folder you created in Step 1.
6. **Test it Out**: Visit [ChatGPT](https://chatgpt.com), [Claude](https://claude.ai), or [Gemini](https://gemini.google.com). You should see the "📌 Rules" button in the bottom right corner!

## Technical Details
- **Manifest V3**: Compliant with the latest Chrome extension standards.
- **Pure Vanilla JS/CSS**: No external libraries used for maximum performance and security.
- **Isolated Styling**: All CSS classes are prefixed with `pg-` to prevent layout breaks on host sites.
- **Dark Mode Support**: Automatically adjusts colors based on your system/site theme.
